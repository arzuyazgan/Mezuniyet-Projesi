export const MenuItems = [
  {
    title:"Anasayfa",
    url:"/",
    cname:"nav-links",
    icon:"fa-solid fa-house-user"
  },
  {
    title:"Hakkımızda",
    url:"/about",
    cname:"nav-links",
    icon:"fa-solid fa-circle-info"
  },
  {
    title:"Proje Fotoğrafları",
    url:"/services",
    cname:"nav-links",
    icon:"fa-solid fa-briefcase"
  },
  {
    title:"İletişim",
    url:"/contact  ",
    cname:"nav-links",
    icon:"fa-solid fa-address-book"
  }
];
